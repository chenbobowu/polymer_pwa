CREATE VIEW responseview AS
  SELECT
    `c1gcsandbox`.`answer`.`question_id` AS `question_id`,
    `r`.`response_id`                    AS `response_id`,
    `r`.`answerxansweroption_id`         AS `answerxansweroption_id`,
    `r`.`responsecollection_id`          AS `responsecollection_id`,
    `r`.`custom_question`                AS `custom_question`,
    `r`.`custom_answer`                  AS `custom_answer`,
    `r`.`custom_answeroption`            AS `custom_answeroption`,
    `r`.`qid`                            AS `qid`
  FROM (((`c1gcsandbox`.`response` `r`
    JOIN `c1gcsandbox`.`responsecollection`
      ON ((`r`.`responsecollection_id` = `c1gcsandbox`.`responsecollection`.`responsecollection_id`))) JOIN
    `c1gcsandbox`.`answerxansweroption`
      ON ((`r`.`answerxansweroption_id` = `c1gcsandbox`.`answerxansweroption`.`answerxansweroption_id`))) JOIN
    `c1gcsandbox`.`answer` ON ((`c1gcsandbox`.`answerxansweroption`.`answer_id` = `c1gcsandbox`.`answer`.`answer_id`)));

