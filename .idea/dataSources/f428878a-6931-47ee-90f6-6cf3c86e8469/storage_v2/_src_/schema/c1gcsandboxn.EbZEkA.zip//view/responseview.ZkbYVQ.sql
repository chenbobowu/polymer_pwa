CREATE VIEW responseview AS
  SELECT
    `c1gcsandboxn`.`answer`.`question_id` AS `question_id`,
    `r`.`response_id`                     AS `response_id`,
    `r`.`answerxansweroption_id`          AS `answerxansweroption_id`,
    `r`.`responsecollection_id`           AS `responsecollection_id`,
    `r`.`custom_question`                 AS `custom_question`,
    `r`.`custom_answer`                   AS `custom_answer`,
    `r`.`custom_answeroption`             AS `custom_answeroption`,
    `r`.`qid`                             AS `qid`
  FROM (((`c1gcsandboxn`.`response` `r`
    JOIN `c1gcsandboxn`.`responsecollection`
      ON ((`r`.`responsecollection_id` = `c1gcsandboxn`.`responsecollection`.`responsecollection_id`))) JOIN
    `c1gcsandboxn`.`answerxansweroption`
      ON ((`r`.`answerxansweroption_id` = `c1gcsandboxn`.`answerxansweroption`.`answerxansweroption_id`))) JOIN
    `c1gcsandboxn`.`answer`
      ON ((`c1gcsandboxn`.`answerxansweroption`.`answer_id` = `c1gcsandboxn`.`answer`.`answer_id`)));

